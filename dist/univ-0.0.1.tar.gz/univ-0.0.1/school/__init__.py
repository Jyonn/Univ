from .school import UniHub

__all__ = ['UniHub']
