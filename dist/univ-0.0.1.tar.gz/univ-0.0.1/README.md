# School in Pypi

![PyPI](https://img.shields.io/pypi/v/school.svg)
![GitHub](https://img.shields.io/github/license/Jyonn/School.svg)

An initial attempt to create a school management system for pypi packages for famous schools all over the world.
